My scene depicts two wizards approaching each other, with one casting a spell on the other. The custom shape is the hats both wizards are wearing,
and is made similar to how the cylindrical tube from the encyclopedia of code was made, however it tapers on one end and splays into
the rim of the hat on the other. 

With look_at(), we follow the initial walking path of the first wizard, then cutting to a panning scene that reveals a second wizard, and ends
with an aerial view over the shoulder of the first wizard as it casts a spell on the second one. 

My hierarchical layers are found in the magic wands, which are children of the arms which are children of the body.